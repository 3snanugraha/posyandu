<?php
echo "<script>window.location='router/Router.php?u=login'</script>";
?>